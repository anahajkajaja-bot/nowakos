<?php
declare(strict_types=1);

// Copy this file to config.local.php and fill secrets on the server only.
// Never upload a real API key into the public HTML or commit it to a repository.
const OTPINSTAN_BASE = 'https://otpinstan.com/api/reseller';

function nowakos_config(string $key, ?string $default = null): ?string {
    $value = getenv($key);
    if ($value !== false && $value !== '') return $value;
    $local = __DIR__ . '/config.local.php';
    if (is_file($local)) {
        $settings = require $local;
        if (is_array($settings) && isset($settings[$key]) && $settings[$key] !== '') {
            return (string)$settings[$key];
        }
    }
    return $default;
}

function provider_api_key(): string {
    $key = nowakos_config('OTPINSTAN_API_KEY');
    if (!$key) throw new RuntimeException('API_KEY_NOT_CONFIGURED');
    return $key;
}

function webhook_secret(): string {
    $secret = nowakos_config('OTPINSTAN_WEBHOOK_SECRET');
    if (!$secret) throw new RuntimeException('WEBHOOK_SECRET_NOT_CONFIGURED');
    return $secret;
}
