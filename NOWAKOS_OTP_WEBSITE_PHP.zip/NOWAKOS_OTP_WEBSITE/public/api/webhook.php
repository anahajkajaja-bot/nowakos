<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    $body = file_get_contents('php://input') ?: '';
    $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
    $webhookId = $_SERVER['HTTP_X_WEBHOOK_ID'] ?? '';
    if ($body === '' || $signature === '' || $webhookId === '') {
        http_response_code(400); echo json_encode(['ok' => false, 'error' => 'MISSING_WEBHOOK_HEADERS']); exit;
    }
    $expected = hash_hmac('sha256', $body, webhook_secret());
    if (!hash_equals($expected, $signature)) {
        http_response_code(401); echo json_encode(['ok' => false, 'error' => 'INVALID_SIGNATURE']); exit;
    }
    $payload = json_decode($body, true);
    if (!is_array($payload) || empty($payload['event'])) {
        http_response_code(400); echo json_encode(['ok' => false, 'error' => 'INVALID_PAYLOAD']); exit;
    }

    // Idempotency and durable event processing must be connected to the NOWAKOS
    // database before enabling live sales. This endpoint verifies authenticity only.
    // Do not print OTP codes or secrets into server logs.
    http_response_code(200);
    echo json_encode(['ok' => true, 'event' => (string)$payload['event'], 'webhook_id' => $webhookId]);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'WEBHOOK_NOT_CONFIGURED']);
}
