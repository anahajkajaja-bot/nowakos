<?php
// Rename to config.local.php on the server, then fill values there.
// Do NOT put real values in this example file or in the HTML.
return [
    'OTPINSTAN_API_KEY' => 'PASTE_NEW_ROTATED_API_KEY_HERE',
    'OTPINSTAN_WEBHOOK_SECRET' => 'PASTE_WEBHOOK_SECRET_HERE',
];
