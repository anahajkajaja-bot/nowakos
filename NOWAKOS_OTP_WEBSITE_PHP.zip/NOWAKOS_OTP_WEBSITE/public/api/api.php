<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Fail closed. The current NOWAKOS HTML login is localStorage-only and does NOT
// create this server session. Do not remove this check to make endpoints public.
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['nowakos_user_id'])) {
    respond(401, ['success' => false, 'error' => 'AUTH_REQUIRED', 'message' => 'Login server NOWAKOS belum terhubung.']);
}

function provider_request(string $path, string $method = 'GET', array $data = [], bool $form = false): array {
    $url = rtrim(OTPINSTAN_BASE, '/') . '/' . ltrim($path, '/');
    if ($method === 'GET' && $data) $url .= '?' . http_build_query($data);
    $headers = ['X-Api-Key: ' . provider_api_key(), 'Accept: application/json'];
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    ];
    if ($method === 'POST') {
        if ($form) {
            $opts[CURLOPT_POSTFIELDS] = http_build_query($data);
            $opts[CURLOPT_HTTPHEADER][] = 'Content-Type: application/x-www-form-urlencoded';
        } else {
            $opts[CURLOPT_POSTFIELDS] = json_encode($data, JSON_UNESCAPED_UNICODE);
            $opts[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json';
        }
    }
    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false) throw new RuntimeException('PROVIDER_CONNECTION_FAILED: ' . $err);
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) return ['http_status' => $code, 'raw' => $raw];
    $decoded['_http_status'] = $code;
    return $decoded;
}

try {
    $action = (string)($_GET['action'] ?? '');
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $input = [];
    if ($method === 'POST') {
        $raw = file_get_contents('php://input') ?: '';
        $json = json_decode($raw, true);
        $input = is_array($json) ? $json : $_POST;
    }

    $routes = [
        // Server 1 (SMS)
        's1.countries' => ['GET', 's1/countries.php', false],
        's1.services'  => ['GET', 's1/services.php', false],
        's1.order'     => ['POST', 's1/order.php', false],
        's1.check'     => ['GET', 's1/check.php', false],
        's1.cancel'    => ['POST', 's1/cancel.php', false],
        's1.resend'    => ['POST', 's1/resend.php', false],
        // OTP Multi SMS
        'ms.services'  => ['GET', 'ms/services.php', false],
        'ms.order'     => ['POST', 'ms/order.php', true],
        'ms.check'     => ['GET', 'ms/check.php', false],
        'ms.cancel'    => ['POST', 'ms/cancel.php', true],
        // Server 6 WhatsApp
        'wa.services'  => ['GET', 'wa/services.php', false],
        'wa.prices'    => ['GET', 'wa/prices.php', false],
        'wa.order'     => ['POST', 'wa/order.php', true],
        'wa.order_group' => ['POST', 'wa/order_group.php', true],
        'wa.check'     => ['GET', 'wa/check.php', false],
        'wa.cancel'    => ['POST', 'wa/cancel.php', true],
        'wa.resend'    => ['POST', 'wa/resend.php', true],
        // Shared endpoints
        'balance'          => ['GET', 'balance.php', false],
        'history'          => ['GET', 'history.php', false],
        'deposit.methods'  => ['GET', 'deposit_methods.php', false],
        'deposit.create'   => ['POST', 'deposit.php', true],
        'deposit.status'   => ['GET', 'deposit_status.php', false],
    ];
    if (!isset($routes[$action])) respond(404, ['success' => false, 'error' => 'UNKNOWN_ACTION']);
    [$allowedMethod, $providerPath, $form] = $routes[$action];
    if ($method !== $allowedMethod) respond(405, ['success' => false, 'error' => 'METHOD_NOT_ALLOWED']);

    $params = $method === 'GET' ? $_GET : $input;
    unset($params['action']);
    $result = provider_request($providerPath, $method, $params, $form);
    $providerStatus = (int)($result['_http_status'] ?? 200);
    unset($result['_http_status']);
    respond($providerStatus >= 400 ? $providerStatus : 200, $result);
} catch (Throwable $e) {
    $message = $e->getMessage();
    $status = str_contains($message, 'API_KEY_NOT_CONFIGURED') ? 503 : 502;
    respond($status, ['success' => false, 'error' => 'BACKEND_ERROR', 'message' => $message]);
}
