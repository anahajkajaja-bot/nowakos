NOWAKOS OTP - PAKET WEBSITE + BACKEND PROVIDER
==============================================

ISI PAKET
---------
public/index.html       Website NOWAKOS OTP versi loading kecil
public/api/api.php      Proxy API OTP Instan (SMS, Multi SMS, WA, deposit)
public/api/webhook.php  Penerima webhook dengan verifikasi HMAC-SHA256
public/api/config.php   Pembaca konfigurasi rahasia server

PENTING: PAKET INI BELUM SIAP TRANSAKSI LIVE
--------------------------------------------
HTML asal masih menggunakan login, saldo, transaksi, dan order berbasis
localStorage. Backend api.php sengaja memerlukan PHP session
$_SESSION['nowakos_user_id']. Login HTML saat ini belum membuat session itu.
JANGAN menghapus pemeriksaan session dan jangan membuat API provider publik.
Jika dibuka apa adanya, website akan tampil, tetapi pemanggilan API provider
akan menolak 401 sampai autentikasi dan saldo dipindahkan ke backend/database.

CARA UPLOAD UNTUK HOSTING PHP
-----------------------------
1. Hosting harus mendukung PHP 8+ dan ekstensi cURL.
2. Upload isi folder public ke document root (misalnya public_html).
3. Salin public/api/config.local.example.php menjadi config.local.php.
4. Isi API Key BARU hasil rotasi dan Webhook Secret dari dashboard provider.
   Jangan gunakan API key yang pernah dikirim ke chat.
5. Pastikan config.local.php tidak dapat diakses publik. .htaccess melindungi
   file konfigurasi untuk Apache/cPanel. Untuk Nginx, buat aturan deny sendiri.
6. Daftarkan webhook provider ke https://DOMAIN-KAMU/api/webhook.php.

FITUR PROXY YANG SUDAH DICAKUP
-----------------------------
- SMS Server 1: countries, services, order, check, cancel, resend
- OTP Multi SMS: services, order, check, cancel
- WhatsApp Server 6: services, prices, order, order_group, check, cancel, resend
- Shared: balance, history, deposit methods, create deposit, deposit status

YANG HARUS DIKERJAKAN SEBELUM LIVE
----------------------------------
- Migrasikan register/login ke PHP session + password_hash.
- Simpan saldo, transaksi, dan order pengguna di database server.
- Terapkan penguncian saldo atomik, refund, validasi kepemilikan order,
  CSRF protection, rate limit, dan audit log.
- Simpan webhook ke database/queue, deduplikasi X-Webhook-ID, lalu proses
  event otp.received, order.cancelled, order.expired, dan deposit.paid.
- Sambungkan UI HTML ke endpoint backend dan uji alur sandbox/nominal kecil.

API INTERNAL (setelah session server terhubung)
------------------------------------------------
GET  /api/api.php?action=s1.countries
GET  /api/api.php?action=s1.services&country_id=7
POST /api/api.php?action=s1.order
GET  /api/api.php?action=ms.services
POST /api/api.php?action=ms.order
GET  /api/api.php?action=wa.services
POST /api/api.php?action=wa.order
GET  /api/api.php?action=deposit.methods
POST /api/api.php?action=deposit.create

CATATAN
-------
File index.html dipertahankan dari versi NOWAKOS sebelumnya, termasuk fitur
UI yang ada. Tidak ada API Key atau Webhook Secret yang ditanam di HTML.
